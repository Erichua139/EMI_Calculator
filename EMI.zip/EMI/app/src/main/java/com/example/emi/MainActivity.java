/*
MainActivity.java
Eric Hua
100777617
 */
package com.example.emi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.EditText;
import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Setting the variables from the activity main page
        EditText Amount = findViewById(R.id.Amount);
        EditText AInterestRate = findViewById(R.id.interestRate);
        EditText period = findViewById(R.id.Period);
        TextView response = findViewById(R.id.response);
        Button myButton = findViewById(R.id.Submit);

        //Used to format decimals
        DecimalFormat df = new DecimalFormat("#.##");

        //Button Listener for the submition button
        myButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Variables used
                double principal, annualInterestRate,monthlyInterestRate,years,totalMonths;
                String temp;
                //Getting the values from the edit texts and converting them to numbers
                temp = Amount.getText().toString();
                principal = Double.parseDouble(temp);
                temp = AInterestRate.getText().toString();
                annualInterestRate = Double.parseDouble(temp);
                temp = period.getText().toString();
                years = Double.parseDouble(temp);

                //finding the monthly interest rate for calculation and how many months
                monthlyInterestRate = (annualInterestRate / 12) /100;
                totalMonths = years * 12;

                //Calculating EMI and formating
                double emi = (principal * monthlyInterestRate * Math.pow(1 + monthlyInterestRate, totalMonths)) / (Math.pow(1 + monthlyInterestRate, totalMonths) - 1);
                emi = Double.parseDouble(df.format(emi));

                //Editing response to print response
                response.setText("Your EMI is: $" + emi);
            }
        });
    }

}